package com.example.gamevaule

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
